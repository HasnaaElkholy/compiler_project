#include <iostream>
#include <vector>
#include <algorithm>

using namespace std ;


// Global Optimization Phase
void globalOptimization(vector<int>& data) {
  
   sort(data.begin(), data.end()); 
}

// Local Optimization Phase
void localOptimization(vector<int>& data) {
    
    for (int i = 1; i < data.size(); ++i) {
        if (data[i] == data[i-1]) { 
            data.erase(data.begin() + i); 
            --i; 
        }
    }
}

int main() {
   vector<int> numbers = {5, 3, 7, 2, 5,8, 8, 3, 1,12, 7, 5};

    cout << "Original Data: ";
    for (int num : numbers) {
      cout << num << " ";
    }
  cout << endl;

   
    globalOptimization(numbers);

   cout << "Data after Global Optimization: ";
    for (int num : numbers) {
       cout << num << " ";
    }
   cout << endl;

    
    localOptimization(numbers);

    cout << "Data after Local Optimization: ";
    for (int num : numbers) {
      cout << num << " ";
    }
    cout << endl;

    return 0;
}

