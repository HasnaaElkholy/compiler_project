    #include <iostream>
#include <unordered_map>
using namespace std ;

unordered_map<int, int> cache; 
int fib(int n) {
    if (cache.find(n) != cache.end()) {
        return cache[n];
    }
    if (n <= 1) {
        
        return n;
    }
    int result = fib(n - 1) + fib(n - 2);
    cache[n] = result; 
    return result;
}

int main() {
    int n ; 
   cout<<"Enter your number : ";
   cin>>n;
    cout << "Fibonacci of " << n << " is: " << fib(n) << endl;
    return 0;}